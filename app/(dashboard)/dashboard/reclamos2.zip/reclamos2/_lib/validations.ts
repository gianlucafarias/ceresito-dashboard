import { tasks } from "@/db/schema"
import * as z from "zod"

export const searchParamsSchema = z.object({
  page: z.coerce.number().default(1),
  per_page: z.coerce.number().default(10),
  sort: z.string().optional(),
  detalle: z.string().optional(),
  estado: z.string().optional(),
  prioridad: z.string().optional(),
  from: z.string().optional(),
  to: z.string().optional(),
  operator: z.enum(["and", "or"]).optional(),
})

export const getTasksSchema = searchParamsSchema

export type GetTasksSchema = z.infer<typeof getTasksSchema>

export const createTaskSchema = z.object({
  detalle: z.string(),
  tipo: z.string(), 
  estado: z.string(),
  prioridad: z.string(),
})

export type CreateTaskSchema = z.infer<typeof createTaskSchema>

export const updateTaskSchema = z.object({
  detalle: z.string().optional(),
  tipo: z.string().optional(),
  estado: z.string().optional(),
  prioridad: z.string().optional(),
})

export type UpdateTaskSchema = z.infer<typeof updateTaskSchema>